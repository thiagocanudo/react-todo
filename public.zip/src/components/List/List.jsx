import { useState } from "react";
import { Task } from "../Task/Task"
import { ContainerList } from "./styles"

export function List(){
    // const inputTarefa = document.querySelector('#inputTarefa').value;
    
    // [estado, função atualizadora] = valor inicial
    
    // const [taskList, setTaskList] = useState([
    //         {titulo: 'Tarefa 1', id: 1},
    //         {titulo: 'Tarefa 2', id: 2},
    // ]);

    const [taskList, setTaskList] = useState([]);    
    const [newTask, setNewTask] = useState('');

    function addTask(e){
        e.preventDefault();
        
        let idTask = new Date().getTime();

        setTaskList([...taskList, {titulo: newTask, id: idTask}]);
        // console.log(taskList);
        setNewTask('');
    }

    // const input = document.querySelector('input');
    // const button = document.querySelector('button');
    // if(input != ''){
    //     button.disabled = true;
    // }

    return (

        <>
            <ContainerList>
                <form onSubmit={addTask}> {/*chama a função no click e no enter */}
                    <input
                        id="inputTarefa"
                        type="text"
                        placeholder="Digite sua tarefa"
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                    />
                    <button
                        type="submit"
                        disabled={newTask == ""}
                    >Criar</button>
                </form>

                {/* <Task /> */}

                {
                    taskList.map((item, id) => (
                        <Task tarefa={item.titulo} key={item.id} /*id={item.id}*/ />
                    ))
                }

                {/* <Task tarefa={listagem[0].tarefa} /> */}
            </ContainerList>
        </>
    )
}