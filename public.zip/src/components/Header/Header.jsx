import styles from './Header.module.css'

export function Header(){

  // console.log(styles);


  return (
    <header className={styles.header}>
      <h1>React TODO</h1>
    </header>
  )

}


